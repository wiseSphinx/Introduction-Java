package com.datorium.Datorium.API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatoriumApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
